export TEST_PHP_EXECUTABLE=/usr/bin/php
$TEST_PHP_EXECUTABLE run-tests.php  swoole_*	--set-timeout 10
